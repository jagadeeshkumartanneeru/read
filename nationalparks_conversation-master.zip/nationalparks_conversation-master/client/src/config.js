const apiHost = '';
const apiRoot = `${apiHost}/natparks/api/v1`

export default {
  apiRoot
};
